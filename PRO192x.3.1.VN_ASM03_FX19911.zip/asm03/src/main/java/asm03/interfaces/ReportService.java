package asm03.interfaces;

public interface ReportService {
    void log(double amount);
}

package asm03.interfaces;

public interface Withdraw {
    boolean withdraw(double amount);
    boolean isAccepted(double amount);
}

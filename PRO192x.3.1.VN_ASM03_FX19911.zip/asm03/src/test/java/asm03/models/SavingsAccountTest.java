package asm03.models;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class SavingsAccountTest {

    // Test số tiền rút nhỏ hơn 50000 sử dụng hàm withdraw và assertEqual
    @Test
    void testWithdraw1() {
        // Assertions.assertEquals(true, new SavingsAccount(50000).withdraw(50000));
    }
}

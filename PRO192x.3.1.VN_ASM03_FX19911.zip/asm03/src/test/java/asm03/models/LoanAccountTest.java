package asm03.models;

import org.junit.jupiter.api.Test;

public class LoanAccountTest {
    @Test
    void testWithdraw() {

    }
}
